// making the cloud move forward once clicked on

class Cloud {
  constructor(x, y, R = 80, r = 40) {
    this.x = x;
    this.y = y;
    this.R = R;
    this.r = r;
    this.cx = [];
    this.cy = [];
    this.cr = [];
    for (var i = 0; i < 40; i++) {
      this.cx.push(Math.floor(Math.random()*this.R)) 
      this.cy.push(Math.floor(Math.random()*this.r))
      this.cr.push(Math.floor(Math.random()*15) + 15)
    }
    
  }
  
  show() {
    fill(255);
    noStroke();
    ellipse(this.x, this.y, this.R, this.r)
    for (var i = 0; i < this.cx.length; i++) {
      var tempX = this.x + (this.cx[i] - (this.R/2))
      var tempY = this.y + (this.cy[i] - (this.r/2))
      circle(tempX,tempY,this.cr[i])
    }
  }
}//end of cloud class
class Fishingrod{
    constructor(x,y,h,w) {
      this.x = x
      this.y = y
      this.h = h
      this.w = w
      this.fish = false;
    }
  
  show() {
    translate(this.x, this.y)
    rotate(0.1*TAU)
    rect(0, 0, this.h, this.w);
    rotate(-0.1*TAU);
    translate(-this.x, - this.y);
  }
  
}

class Bobber{
  constructor(x,y){
    this.x = x;
    this.stopY = y;
    this.y = y;
    this.velocity = 5
    this.diameter = 20
    
  }
  show(rodObj) {
    line(rodObj.x, rodObj.y, this.x, this.y)
   circle(this.x,this.y,this.diameter) 
    
  }
  
  move() {
    if (this.fish) {
      if (this.y > 450) {
        this.velocity = -1 * this.velocity;
      }
      this.y += this.velocity
      if (this.y <= this.stopY) {
        this.fish = false
        this.y = this.stopY;
        this.velocity = -1 * this.velocity;
      }
    }
  }
  
}

var rod;
var bobber;
function setup() {
  createCanvas(500, 500)
  cloud = new Cloud(100, 100)
  rod = new Fishingrod(200,200, 10, 100)
  bobber = new Bobber(210,240,this.diameter)
}

var cloud;
function draw() {
  background(220);
  //cloud.show();
  rod.show();
  bobber.move();
  bobber.show(rod);
}


function mouseClicked() {
  bobber.fish = true;
  if (cloud.x === 30) {
    cloud.x = 100;
  } else {
    cloud.x = 30;
  }

}   
//fishing poles
//hook-no fill semicircle
//fishingrod class