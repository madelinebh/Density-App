// creating the cloud function that will hold the questions
function setup() {
  createCanvas(400, 400);
  

var cloud;
function draw() {
  background(220);
  cloud = circle(30,30,20)
}
}
// making the cloud move forward once clicked on

var cloud;
function draw() {
  background(220);
  cloud = circle(30,30,20)
}


function mouseClicked() {
  if (cloud.x === 30) {
    cloud = 255;
  } else {
    value = 0;
  }
}