// making the cloud move forward once clicked on

class Cloud {
  constructor(x, y, R = 80, r = 40) {
    this.x = x;
    this.y = y;
    this.R = R;
    this.r = r
    this.cx = [];
    this.cy = [];
    this.cr = [];
    for (var i = 0; i < 40; i++) {
      this.cx.push(Math.floor(Math.random()*this.R)) 
      this.cy.push(Math.floor(Math.random()*this.r))
      this.cr.push(Math.floor(Math.random()*15) + 15)
    }
    
  }
  
  show() {
    fill(255);
    noStroke();
    ellipse(this.x, this.y, this.R, this.r)
    for (var i = 0; i < this.cx.length; i++) {
      var tempX = this.x + (this.cx[i] - (this.R/2))
      var tempY = this.y + (this.cy[i] - (this.r/2))
      circle(tempX,tempY,this.cr[i])
    }
  }
}

function setup() {
  createCanvas(500, 500)
  cloud = new Cloud(100, 100)
}

var cloud;
function draw() {
  background(220);
  cloud.show();
}


function mouseClicked() {
  if (cloud.x === 30) {
    cloud.x = 0;
  } else {
    cloud.x = 30;
  }
}